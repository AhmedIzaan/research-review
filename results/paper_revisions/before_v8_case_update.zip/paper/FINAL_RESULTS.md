# Finalized results for the research paper

Evidence freeze: 15 November 2026. Primary controlled study: `smoke_v2`. All comparisons are descriptive.

## Controlled sample

- Independent seed papers: 2 (ResearchAgent and SciMON).
- Final condition outputs: 12 across six configurations.
- Accepted distinct judgments: 16; score rows with aliases: 26.
- One generation per seed was shared by all conditions. No human ratings were collected.

## Final mean ratings

| Configuration | N | F | C | I | G |
|---|---:|---:|---:|---:|---:|
| one_shot | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| generic | 3.5 | 3.5 | 4.0 | 4.0 | 4.0 |
| full | 3.5 | 4.0 | 4.5 | 4.0 | 4.5 |
| no_feasibility | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| no_contrarian | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| no_novelty_retrieval | 4.0 | 3.5 | 4.0 | 4.5 | 4.0 |

N: novelty; F: feasibility; C: clarity; I: importance; G: evidence grounding. All use a 1–5 model-judge rubric.

Full minus one-shot: N −0.5, F +0.5, C +0.5, I 0.0, G +0.5. This is a possible novelty–feasibility trade-off in two cases, not a demonstrated general effect.

## Ablations and progression

Removing feasibility or contrarian review gives identical means, preventing a ranking of their usefulness. Removing additional novelty retrieval raises mean novelty and importance but lowers feasibility, clarity and grounding. Inference budgets are unequal.

Full-panel means by stage:

| Stage | N | F | C | I | G |
|---|---:|---:|---:|---:|---:|
| 0 | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| 1 | 4.0 | 4.0 | 5.0 | 4.0 | 4.0 |
| 2 | 4.0 | 4.0 | 4.5 | 4.5 | 4.5 |
| 3 | 3.5 | 4.0 | 4.5 | 4.0 | 4.5 |

Gains are not monotonic. Stage 0 is the initial proposal.

## Execution and method audits

- API attempts: 141; successful: 135.
- Request errors: {'NetworkOrTimeoutError': 2, 'HTTP 503': 4}.
- Reported tokens: at least 815,568; unknown usage in 6 attempts.
- Suite wall time: 38.56 minutes.
- One generic reviewer returned a wrong role in the SciMON run. The last valid proposal was retained.
- Off-role score fields occurred in 71 of 88 accepted reviews. Later strict contracts are not retroactively applied.

## Separate interactive case

Run `fff8592ef95a73dda616`: 13 successful calls, 182.66 seconds, 133,543 tokens. Judge novelty changed 3→4, while the final novelty specialist remained at 2. The judge missed two close prior papers. Its six final-review citation claims were rated supported by a separate same-model audit. None of these values establishes that the proposal was objectively novel or feasible.

A subsequent offline retrieval regression found 23 records using seven queries, including the missed papers. No new live shared-evidence ratings are available.

## Files and limits

`results/final_individual_scores.csv` preserves every final rating; `paired_differences.csv` preserves paired changes; `resource_records.csv` preserves individual runtime/call records. `source_hashes.json` binds this analysis to the unchanged source files.

No p-values, confidence intervals, human agreement, billing costs, or scientific-execution success rates are asserted.
