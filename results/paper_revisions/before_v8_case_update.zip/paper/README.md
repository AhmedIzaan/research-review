# IEEE-style research paper package

**Title:** Literature-Grounded Research Idea Generation Using Specialized Multi-Agent Reviewers: A Pilot Study

The six-page reading PDF presents the completed work as a pilot systems study. It contains three figures, four tables, twelve references, and an explicit account of the limitations and subsequent implementation changes. No new LLM experiments were run to prepare this paper.

## Open these files

- `Research_Paper_IEEE.pdf` — six-page, two-column US Letter reading copy with embedded serif fonts.
- `Research_Paper_IEEE.docx` — editable Word document; Times New Roman, one-column title and two-column body.
- `main.tex` — IEEEtran conference source, including the bibliography.
- `references.bib` — reusable bibliographic records corresponding to the twelve numbered references.
- `manuscript.md` — canonical editable prose used to generate the PDF, DOCX, and TeX files.
- `FINAL_RESULTS.md` and `results/` — finalized descriptive results, individual scores, paired differences, iteration scores, request-resource records, and source hashes.
- `figures/` — the schematic and actual-result plots in both 300-dpi PNG and vector PDF.
- `verification.json` — checks performed and rendering limitations.

Names and order were taken from the supplied Agentic AI literature review: Safee Ahmad, Ahmed Izaan, Fatima Ajmal. Confirm the author order and affiliation before submission. Email addresses and contribution statements were not invented.

## What the paper establishes

The controlled study is `results/smoke_v2`: two independent seed papers, six conditions, twelve final outputs, sixteen distinct accepted judgments and twenty-six score rows including shared aliases. It is not a twenty-paper evaluation. The full panel has higher mean feasibility, clarity and grounding than one-shot, lower novelty, and equal importance. The paper reports descriptive observations without significance claims.

The paper also reports two important audits. First, 71 of 88 accepted pilot reviews contained at least one off-role numeric score, weakening claims of clean numerical specialization. Second, the later contradiction/abstention case exposed unequal evidence between the novelty reviewer and the independent judge. These findings are retained rather than hidden.

The stricter score schemas, final reassessment, assumption checks, claim-support audit and shared-evidence judge are described as post-pilot changes. Their later traces or offline retrieval checks do not replace the controlled pilot or establish a new causal performance result. In particular, new live ratings under the shared-evidence judge have not been collected.

The original quotation-transcription pilot, interactive demonstrations and controlled pilot are not pooled. There are no collected human ratings, no human-agreement estimates, no executed generated scientific hypotheses, and no trained/fine-tuned LLM in these experiments.

## Rebuild and verify

From the project root with its existing environment:

```bash
../.venv/bin/python scripts/finalize_paper_results.py
../.venv/bin/python scripts/build_paper_figures.py
../.venv/bin/python scripts/build_ieee_paper.py
../.venv/bin/python scripts/verify_paper.py
```

These commands read saved results and do not make API calls. Retain the project data and raw audit directories when recomputing provenance checks. The paper package contains the numeric summaries; the complete raw request/response traces remain in the project.

To compile the authoritative conference-class version, open `main.tex` in Overleaf or run `latexmk -pdf main.tex` from this directory in a TeX environment with IEEEtran. The separate LaTeX source archive places `main.tex` at the archive root with its figures. The embedded `thebibliography` means BibTeX is not required for this version; `references.bib` is provided for citation-manager or later template use.

## Format and submission status

IEEE conference **format** was requested; no specific conference or submission track has been selected. This is not an accepted publication or a claim of venue eligibility. A pilot, student-research, work-in-progress or systems-oriented track is a more defensible framing than a large-scale efficacy claim.

The PDF was rendered locally with Matplotlib's embedded-font backend because TeX is unavailable and LibreOffice conversion failed in the restricted environment. The DOCX package and XML were validated, but Word/LibreOffice visual rendering could not be checked. The PDF is an IEEE-style reading copy, not PDF eXpress certification. Use the supplied IEEEtran source for the final venue build and apply that venue's page limit, anonymity rules and PDF checks.

The acknowledgment identifies OpenAI Codex assistance in drafting and coding and Gemini's experimental role. It does not claim an unaided human manuscript. IEEE's [authoring guidance](https://conferences.ieeeauthorcenter.ieee.org/write-your-paper/authoring-tools-and-templates/) and [AI-content policy](https://magazines.ieeeauthorcenter.ieee.org/get-started-with-ieee-magazines/publishing-ethics/guidelines-policies/submission-and-peer-review-policies/) should be checked against the selected venue's instructions. The authors should review the manuscript's scientific interpretation and references before any external submission.
