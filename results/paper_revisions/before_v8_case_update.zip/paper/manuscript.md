# Literature-Grounded Research Idea Generation Using Specialized Multi-Agent Reviewers: A Pilot Study

Safee Ahmad, Ahmed Izaan, and Fatima Ajmal

National University of Computer and Emerging Sciences (FAST–NUCES), Islamabad, Pakistan

## Abstract

A research proposal can become easier to implement while becoming less original. This tension makes reviewer-guided scientific ideation difficult to evaluate. We implement a literature-grounded workflow that generates a structured proposal, obtains independent critiques from novelty, feasibility, clarity/importance, and contrarian reviewers, and revises the proposal for up to three rounds. A frozen corpus of 2,114 scholarly abstracts supports generation and prior-art searches. We compare one-shot generation, generic iterative review, the full panel, and three component-removal conditions using shared initial proposals from two seed papers. A separately prompted judge evaluates five dimensions on a 1–5 scale. Relative to one-shot generation, the full panel receives mean changes of −0.5 in novelty, +0.5 in feasibility, +0.5 in clarity, 0.0 in importance, and +0.5 in evidence grounding. Improvements are not monotonic across rounds, and the ablations do not identify a uniquely useful reviewer. Trace audits reveal frequent off-role scoring in the pilot and, in a later case, a novelty disagreement associated with unequal literature coverage. These findings motivate stricter response contracts and shared-evidence judging. The study demonstrates an inspectable implementation and a possible novelty–feasibility trade-off, rather than establishing general superiority.

## Index Terms

Agentic AI, scientific ideation, multi-agent review, retrieval-augmented generation, LLM evaluation, reproducibility.

## I. Introduction

Research idea generators are usually asked to satisfy several goals at once: identify an important problem, depart meaningfully from prior work, and propose an experiment that someone can actually carry out. These goals need not move together. An ambitious mechanism may be difficult to implement, whereas narrowing it to fit a small computing budget may remove the part that made it interesting. Human evaluation of LLM-generated ideas has already exposed this tension between judged novelty and feasibility [1].

Literature-grounded systems offer a practical way to make ideation more inspectable. ResearchAgent organizes generation and revision around scientific papers and reviewing agents [2], while SciMON repeatedly compares proposed directions with earlier work [3]. The attraction of a review loop is straightforward: weaknesses can be identified before a researcher invests in an experiment. Its difficulty is equally important. A fluent critique is not necessarily a correct critique, and a higher model-assigned score is not evidence that a proposal will succeed.

This paper studies a bounded implementation of specialized reviewing. A novelty reviewer searches related literature; a feasibility reviewer examines resources and experimental practicality; a clarity/importance reviewer checks whether the question and method are specific and useful; and a contrarian reviewer challenges the central assumptions. Reviewers receive the same current proposal without seeing one another's critiques. Their feedback is then supplied to a revision step, and every version is retained.

We ask three questions. RQ1: How do the panel's independently judged outputs differ from one-shot generation and generic iterative review? RQ2: What changes when feasibility review, contrarian review, or additional novelty retrieval is removed? RQ3: How do ratings evolve across rounds, and what execution traces reveal limitations of the evaluation itself?

Our contribution is an auditable implementation and a comparative pilot, not the invention of multi-agent reviewing. We provide matched initial proposals, baseline and ablation traces, individual rubric scores, and resource records. We also examine failures that aggregate scores can obscure: a wrong-role response, leakage of scores across specialist roles, and an independent judge that missed relevant prior work. The sample contains only two independent seed papers; consequently, all comparisons are descriptive.

## II. Related Work

Scientific ideation has moved beyond unrestricted brainstorming. ResearchAgent combines literature connections and iterative reviewing [2]. SciMON retrieves scientific inspirations and explicitly revises ideas in response to overlap with prior papers [3]. Our system takes the review–revision pattern as its starting point, but uses a small, fixed abstract corpus rather than reproducing ResearchAgent's academic graph or entity store.

Multiple interacting agents are also established in this area. Su et al.'s Virtual Scientists framework uses collaborative generation, evaluation, and refinement [4]. InfAL uses adversarial agent interactions at inference time to improve ideation without additional model training [5]. These studies rule out a broad claim that diverse or adversarial reviewing is new. The narrower question here is what a particular combination of roles and retrieval does under shared inputs and an explicitly recorded inference budget.

InnoEval is especially close to our evaluation concerns. It frames idea assessment as knowledge-grounded, multi-perspective reasoning and combines evidence search with a review board [6]. Our work does not claim a more capable general evaluator. It instead examines a lightweight implementation whose source selection, feedback, revisions, and failures can be inspected directly.

Evaluation reliability remains a separate problem. Si et al. identify limitations of LLM self-evaluation in scientific ideation [1]. Liang et al. find useful aspects of automated paper feedback while retaining a central role for human review [7]. ReviewEval distinguishes factual accuracy, analytical depth, constructiveness, and adherence to review guidelines [8]. More generally, LLM-as-a-judge studies document biases that make model ratings imperfect proxies for human judgment [9]. We therefore keep refinement feedback separate from outcome evaluation and avoid treating either as verified scientific success.

## III. System and Study Protocol

### A. Literature and Structured Proposals

The retriever searches 2,114 records containing titles, authors, years, abstracts, URLs, and available DOIs. The collection contains 2,097 usable abstracts from six pinned ACL Anthology XML collections and 17 additional project anchors. Twenty-five source records without usable titles or abstracts were excluded. The snapshot is predominantly from 2024–2025, with additional anchors, and is not a comprehensive scientific index.

Retrieval uses a BM25-style lexical ranker [10], with k1 = 1.5, b = 0.75, and a threefold title-term weight. Queries and returned sources are cached and logged. The generator receives the seed paper and related records, then produces a proposal with a research problem, gap, methodology, expected contribution, experimental setup, evaluation strategy, feasibility assumptions, references, and up to three search queries. These fields describe intended research; the workflow does not execute the proposed scientific experiments.

### B. Review, Aggregation, and Revision

Figure 1 summarizes the evaluated workflow. All roles use the same pretrained model through separate requests. Information isolation means that one reviewer cannot read another review before producing its own critique; it does not mean that the reviewers have different model weights. Calls are sequential to respect the available API rate limit.

The novelty role performs additional proposal-specific searches and identifies overlapping mechanisms. Feasibility review concerns data, computation, implementation complexity, and the stated project constraints. Clarity/importance review examines specificity, experimental logic, and scientific value. Contrarian review seeks a substantive failure mode or simpler competing explanation. Aggregation preserves the individual criticisms, evidence, and disagreements instead of reducing the panel to a single average. A generator then revises the proposal from the complete feedback.

Review outputs are schema-validated. In the controlled pilot, however, the schema permitted optional scores outside a reviewer's assigned dimensions; prompts requested specialization but did not enforce score exclusivity. This limitation is measured in Section V. Later schema restrictions are reported separately and are not retroactively attributed to the pilot.

The controller stops at three rounds, an unchanged proposal, failure of all reviewers, a failed revision, or the API-attempt limit. Failed feedback is retained, and a failed revision does not replace the last valid proposal. Although a LangGraph adapter is implemented, the recorded pilot used the bounded Python state engine.

![Figure 1. Evaluated workflow. Reviewer requests are isolated before aggregation. The independent judge does not return feedback to the refinement loop. Final reassessment and claim-support auditing were added after the controlled pilot.](figures/architecture.png)

### C. Citation Traceability

The novelty reviewer must cite retrieved literature. To avoid errors caused by copying quotations, the citation interface presents source passages with stable identifiers. The model selects an allowed identifier, and the program attaches its paper ID and exact excerpt. Unknown identifiers and mismatched excerpts are rejected. Retrieved text is treated as untrusted source content, not as executable instructions.

This validates provenance, not semantic support. A real excerpt can be irrelevant to a claim, and relevant prior work can remain outside the corpus or search results. We therefore use “literature-grounded novelty checking” to mean an evidence-backed overlap assessment within the retrieved sources, rather than a proof that an idea has never appeared before.

### D. Comparisons and Outcome Evaluation

Table I defines the six conditions. The generic baseline uses one broad reviewer and iterative revision; it is a simplified ResearchAgent-inspired baseline, not a reproduction of the published system. The three ablations remove feasibility review, contrarian review, or additional novelty searches. The last condition retains the original literature context and all four reviewer roles.

TABLE I. Experimental conditions and nominal additional calls for three rounds. Initial generation is shared and excluded from this count.

| Condition | Reviewers per round | Extra calls |
|---|---|---:|
| One-shot | None | 0 |
| Generic | One general reviewer | 6 |
| Full panel | Four specialists | 15 |
| No feasibility | Three specialists | 12 |
| No contrarian | Three specialists | 12 |
| No novelty search | Four; no extra search | 15 |

A separate judge receives a proposal, practical constraints, and retrieved source passages, but no reviewer scores, condition labels, or round labels. It rates novelty, feasibility, clarity, importance, and evidence grounding from 1 to 5. The rubric anchors low scores to serious deficiencies and high scores to strong, specific justification. Grounding measures judged support for literature claims; it is not citation-count accuracy.

The pilot judge retrieved evidence using the first proposal query, with up to eight results. Its evidence was therefore not fixed across all proposals. Identical proposal content was judged once and reused across aliases. Initial and all full-panel revisions were evaluated; other iterative conditions contributed their final valid proposal. Reviewer scores were not used as the outcome measure.

## IV. Experimental Setup

The controlled study uses ResearchAgent [2] and SciMON [3] as two purposively selected seeds from a fixed 20-paper manifest. Both concern scientific ideation, making domain interpretation manageable but limiting generalization. For each seed, one initial proposal was generated and reused by all six conditions. Condition order was deterministically shuffled, and one replicate was run per seed.

The stored model identifier is gemini-3.5-flash-lite for both generation and judging. Temperature was 0.4, the maximum output length was 4,096 tokens, the request interval was 15 seconds, and up to three attempts were allowed per call. The ordering seed was 20261107. It controls experimental bookkeeping, not deterministic sampling by the hosted model. Provider-side model weights were not pinned.

Every condition received the same practical constraint: a six-week university AI/NLP project using one 12 GB consumer GPU or API access, lawful public datasets, and no LLM training. Differences in reviewer count created unequal inference budgets; the experiment does not isolate role specialization from additional computation.

We report individual ratings, descriptive means, paired differences, and observed ranges. The independent units are the two seeds, not the twelve condition outputs, twenty-six score rows, or number of agents. We do not report significance tests, confidence intervals, or population effect estimates. The earlier quotation-transcription diagnostic run is preserved but excluded because its citation interface differed. Later interactive runs are case studies, not additional matched samples.

Reported summaries can be recomputed from the retained responses, request audits, and score records. Historical prompts are preserved in those audits. The current application includes post-pilot changes, so rerunning it is a new protocol evaluation rather than a bit-for-bit reproduction of this study.

## V. Results

### A. Baseline Comparison

All twelve final-condition outputs received accepted judgments. Table II gives the final means; the accompanying data preserve all per-seed ratings. The full panel changes mean novelty from 4.0 to 3.5 relative to one-shot generation, while feasibility rises from 3.5 to 4.0, clarity from 4.0 to 4.5, and grounding from 4.0 to 4.5. Importance remains 4.0. The generic baseline has the same mean novelty as the full panel and lower means on feasibility, clarity, and grounding, but one generic run ended early.

TABLE II. Final mean judge ratings. N: novelty; F: feasibility; C: clarity; I: importance; G: grounding. Each row has two seeds; scores range from 1 to 5.

| Condition | N | F | C | I | G |
|---|---:|---:|---:|---:|---:|
| One-shot | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| Generic | 3.5 | 3.5 | 4.0 | 4.0 | 4.0 |
| Full panel | 3.5 | 4.0 | 4.5 | 4.0 | 4.5 |
| No feasibility | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| No contrarian | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| No novelty search | 4.0 | 3.5 | 4.0 | 4.5 | 4.0 |

The per-seed pattern is more informative than the mean alone. For the SciMON seed, the full proposal moves from novelty 4 and feasibility 3 to novelty 3 and feasibility 4. For the ResearchAgent seed, novelty and feasibility remain 4, while clarity and grounding each rise from 4 to 5. Thus, full-panel final novelty spans 3–4 and feasibility is 4 for both seeds; one-shot feasibility spans 3–4. Figure 2 shows these paired observations rather than implying a well-estimated population average.

![Figure 2. Baseline comparison by seed. A is one-shot and B is generic iterative review. Each marker is one independent seed's judged proposal; lines only connect matched observations.](figures/baseline_pairs.png)

These observations are compatible with a novelty–feasibility trade-off. They do not show that the reviewers caused a general improvement. The full panel spends more calls, the judge is the same model family, and the evidence available to the judge can change with the proposal.

### B. Ablations

Removing feasibility or contrarian review produces the same aggregate ratings: novelty increases by 0.5 relative to the full panel, while feasibility, clarity, and grounding each decrease by 0.5. The pilot therefore cannot identify which of these reviewers contributes most. Identical averages also do not establish identical mechanisms or redundant feedback.

Removing additional novelty retrieval yields novelty 4.0 instead of 3.5 for the full system. Grounding falls from 4.5 to 4.0, while importance rises from 4.0 to 4.5. Additional retrieval consequently does not improve judged novelty in this sample. A plausible interpretation is that overlap criticism constrains the revision; another is that the judge's incomplete evidence changes the rating. The present design cannot separate these explanations.

### C. Iterative Refinement

Table III and Figure 3 show that more rounds are not consistently better. Feasibility improves after the first round and then remains unchanged. Clarity peaks at round 1. Novelty falls at the final round, and importance rises temporarily before returning to its initial mean. With one judge response per distinct proposal, rating noise cannot be separated from a real change in proposal quality.

TABLE III. Full-panel mean ratings across refinement stages, with two seeds at each stage.

| Stage | N | F | C | I | G |
|---|---:|---:|---:|---:|---:|
| Initial | 4.0 | 3.5 | 4.0 | 4.0 | 4.0 |
| Round 1 | 4.0 | 4.0 | 5.0 | 4.0 | 4.0 |
| Round 2 | 4.0 | 4.0 | 4.5 | 4.5 | 4.5 |
| Round 3 | 3.5 | 4.0 | 4.5 | 4.0 | 4.5 |

![Figure 3. Full-panel trajectories for novelty, feasibility, clarity, and grounding. Each line follows one seed through the initial proposal and three revisions. Importance is reported in Table III.](figures/iteration_pairs.png)

### D. Execution Cost and Failures

The study records 141 API attempts: 135 successful responses and six transient request failures, consisting of four HTTP 503 errors and two network/timeouts. The recovered calls account for at least 815,568 provider-reported tokens; six failed requests have unknown usage. Wall time was 38.56 minutes. Configured zero cost rates reflect the available account setup, not verified billing, so we do not claim a monetary cost.

Table IV reports additional request attempts and workflow time after shared initial generation. The initial proposals themselves required one request each and 3.56–14.99 seconds. One-shot's near-zero additional time is therefore not its end-to-end generation latency. Resource figures include retries and are not equal-cost comparisons.

TABLE IV. Observed additional reviewing/refinement resources per seed. Initial generation and independent judging are excluded.

| Condition | Attempts | Seconds |
|---|---:|---:|
| One-shot | 0 | <0.01 |
| Generic | 4–6 | 59.4–90.1 |
| Full panel | 15 | 225.2–225.6 |
| No feasibility | 12–13 | 180.0–303.0 |
| No contrarian | 12–13 | 179.7–194.9 |
| No novelty search | 15–17 | 224.7–363.6 |

The SciMON generic run returned a wrong reviewer role in round 2. It stopped with one successful revision, and its last valid proposal was retained and judged. All sixteen distinct selected proposals received accepted judgments; the twenty-six score rows include reused aliases and are not twenty-six independent observations.

A second audit found off-role numeric scores in 71 of 88 accepted reviewer outputs. The counts were 21 of 24 novelty reviews, 9 of 18 feasibility reviews, 23 of 24 clarity reviews, and all 18 contrarian reviews. The four accepted generic reviews were intended to score multiple dimensions. This leakage limits claims about cleanly separated numerical roles and motivated a schema-level correction rather than another prompt-only request.

## VI. Post-Pilot Case Study and Evaluation Repair

A later topic-based run examined contradiction detection and abstention in retrieval-augmented generation. It used one refinement round, a final reassessment panel, a citation-support audit, and independent initial/final judgments. The run completed thirteen requests without retries in 182.66 seconds, with 133,543 reported tokens. It is a single interactive case under a changed protocol, not an extension of the controlled sample.

The revision replaced multi-step atomic-fact decomposition with a cross-encoder NLI module and added a log-probability abstention baseline. Structured assumption checks proposed a memory-profiling test and a fallback. These checks were plans; no proposed GPU workload was executed. The final contrarian reviewer identified a remaining risk: complementary multi-hop evidence might be mistaken for contradiction, causing excessive abstention.

The novelty specialist rated both versions 2/5, whereas the independent judge rated novelty 3/5 initially and 4/5 after revision. Inspection showed that the judge's broad-query results omitted Transform Retrieval [11] and relevant NLI-based hallucination detection [12], both available to the novelty reviewer. This is a concrete evidence asymmetry, not proof that either rating is correct. The audit judged all six final-review citations supported, illustrating that support for component-level claims does not establish originality of their combination.

The implementation was then hardened in four ways. Wire schemas now permit only assigned role scores. Final proposals can be reassessed after the last revision. Generated proposals must record prior-work comparisons and testable assumption checks. Finally, independent evaluation searches all proposal queries, adds a mechanism query, resolves cited source records, and shares a capped evidence set across matched versions and conditions, without passing reviewer opinions to the judge.

An offline regression using the actual case proposals retrieves 23 source records through seven unique queries and includes both previously missed papers. The cap is 24 records, with missing or omitted sources explicitly logged. This verifies evidence selection only: no new live judge ratings under the shared-evidence protocol are available. The earlier ratings remain unchanged. The strict score contract did hold in all eight reviews of the interactive case, but this does not establish improved idea quality.

## VII. Limitations and Implications

The sample is the principal limitation. Two ideation-focused seed papers cannot represent NLP research, and there are no repeated generations or independent human ratings. A larger fixed sample should include multiple research areas, repeated runs, and blinded human assessment. Its size should follow a precision or power plan rather than a convenient round number.

Model evaluation is another limitation. Generation, reviewing, and judging use the same underlying model, whose prior knowledge may include the seed papers. Separate prompts prevent direct feedback leakage, but they do not eliminate shared biases or memorization. The case study shows that even a separately prompted judge can be poorly informed. Shared evidence improves comparability, but does not ensure that retrieval is complete or that a judgment is correct.

The ablations change both reviewer content and inference allocation. The generic early failure further weakens its comparison with three-round conditions. Off-role scoring in the pilot also blurs the intended division of responsibility. Future experiments should compare the corrected contracts under matched call/token budgets, predefine failure handling, and examine whether textual critiques remain distinct when numerical leakage is prevented.

The retriever sees abstracts, not full methods, negative results, or resource measurements. A matching passage verifies what was supplied, not the truth of a feasibility estimate or a universal novelty claim. The source corpus and judge context are bounded. Broader retrieval and a manually checked prior-art set would help test novelty judgments directly.

Finally, no generated scientific hypothesis was implemented or experimentally validated. Feasibility ratings concern proposals. Neither an asserted memory requirement, a proposed threshold, nor an absence of significant difference constitutes an executed falsification or an equivalence result. The trace interface makes these boundaries visible, but human expertise remains necessary when deciding whether to pursue an idea.

## VIII. Conclusion

We implemented and evaluated a bounded literature-grounded ideation workflow with specialized reviewers, shared-initial baselines, ablations, and inspectable evidence. In the two-seed pilot, the full panel received higher mean feasibility, clarity, and grounding ratings than one-shot generation, alongside lower novelty. Additional rounds did not improve every metric, and the ablations did not identify a most useful reviewer. Trace-level audits exposed score leakage and unequal judge evidence, leading to explicit implementation corrections. The defensible outcome is a reproducible pilot and a clearer account of evaluation failure modes. Establishing reliable quality gains requires a larger, independently assessed study of the corrected protocol.

## Acknowledgment

OpenAI Codex assisted software development, audit-script preparation, and drafting of Sections I–VIII and the abstract. Numerical results, tables, and experimental plots were computed from retained execution records. Gemini generated the research proposals, reviews, and model judgments described in the methods. No human evaluation results or scientific hypothesis-execution outcomes were generated or inferred for this paper.

## References

[1] C. Si, D. Yang, and T. Hashimoto, “Can LLMs Generate Novel Research Ideas? A Large-Scale Human Study with 100+ NLP Researchers,” in Proc. Int. Conf. Learn. Represent. (ICLR), 2025.

[2] J. Baek, S. K. Jauhar, S. Cucerzan, and S. J. Hwang, “ResearchAgent: Iterative Research Idea Generation over Scientific Literature with Large Language Models,” in Proc. NAACL-HLT, vol. 1, 2025, pp. 6709–6738, doi: 10.18653/v1/2025.naacl-long.342.

[3] Q. Wang, D. Downey, H. Ji, and T. Hope, “SciMON: Scientific Inspiration Machines Optimized for Novelty,” in Proc. ACL, vol. 1, 2024, pp. 279–299, doi: 10.18653/v1/2024.acl-long.18.

[4] H. Su et al., “Many Heads Are Better Than One: Improved Scientific Idea Generation by A LLM-Based Multi-Agent System,” in Proc. ACL, vol. 1, 2025, pp. 28201–28240, doi: 10.18653/v1/2025.acl-long.1368.

[5] S. Guo, A. H. Shariatmadari, P. Wang, A. Huang, and A. Zhang, “InfAL: Inference Time Adversarial Learning for Improving Research Ideation,” in Findings of ACL: EMNLP, 2025, pp. 12501–12522, doi: 10.18653/v1/2025.findings-emnlp.667.

[6] S. Qiao et al., “InnoEval: On Research Idea Evaluation as a Knowledge-Grounded, Multi-Perspective Reasoning Problem,” in Proc. ICML, Proc. Mach. Learn. Res., vol. 306, 2026, pp. 101378–101428.

[7] W. Liang et al., “Can Large Language Models Provide Useful Feedback on Research Papers? A Large-Scale Empirical Analysis,” NEJM AI, vol. 1, no. 8, 2024, doi: 10.1056/AIoa2400196.

[8] M. K. Garg, T. Prasad, T. Singhal, C. Kirtani, M. Mandal, and D. Kumar, “ReviewEval: An Evaluation Framework for AI-Generated Reviews,” in Findings of ACL: EMNLP, 2025, pp. 20542–20564, doi: 10.18653/v1/2025.findings-emnlp.1120.

[9] L. Zheng et al., “Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena,” in Advances in Neural Information Processing Systems, vol. 36, 2023.

[10] S. Robertson and H. Zaragoza, “The Probabilistic Relevance Framework: BM25 and Beyond,” Foundations and Trends in Information Retrieval, vol. 3, no. 4, pp. 333–389, 2009, doi: 10.1561/1500000019.

[11] X. Liang and Q. Guo, “Transform Retrieval for Textual Entailment in RAG,” in Proc. NAACL-HLT, vol. 2, 2025, pp. 595–599, doi: 10.18653/v1/2025.naacl-short.50.

[12] D. Galimzianova, A. Boriskin, and G. Arshinov, “From RAG to Reality: Coarse-Grained Hallucination Detection via NLI Fine-Tuning,” in Proc. Fifth Workshop on Scholarly Document Processing, 2025, pp. 353–359, doi: 10.18653/v1/2025.sdp-1.34.
